/* Things to do in code:
 * 1. Add the color sort
 * 2. Add odometry
 * 3. Make PID for both chassis + lady brown better
 * 4. Make PID for Intake???
 * 5. Add second doinker
 * 6. Test out different drive curves
 * 7. Make better Auton Selector
 * 8. Make slew 127 in lateral movements, thats why the robot is slow
*/

#include "main.h"
#include "lemlib/api.hpp" // IWYU pragma: keep
#include "pros/misc.h"
#include "pros/rotation.hpp"
#include "pros/rtos.hpp"
#include "pros/llemu.hpp"

#define INTAKE_PORT 21
#define LADYBROWN_PORT -6
#define LADYBROWN2_PORT 18
#define CLAMP 'B'
#define DOINKER 'A'
pros::Rotation rotationSensor(5);
pros::adi::DigitalOut Clamp(CLAMP);
pros::adi::DigitalOut Doinker(DOINKER);
pros::Motor Intake(INTAKE_PORT);
pros::Motor LadyBrown(LADYBROWN_PORT);
pros::Motor LadyBrown2(LADYBROWN2_PORT);
pros::Optical colorSensor(19);
pros::Controller master(pros::E_CONTROLLER_MASTER);


// motor groups
pros::MotorGroup
    leftMotors({-8, -9, -10},
               pros::MotorGearset::blue); // left motor group - ports 3
                                          // (reversed), 4, 5 (reversed)
pros::MotorGroup rightMotors(
    {1, 2, 3},
    pros::MotorGearset::blue); // right motor group - ports 6, 7, 9 (reversed)

// Inertial Sensor on port 4
pros::Imu imu(4);

// tracking wheels
// horizontal tracking wheel encoder. Rotation sensor, port 20, not reversed
// pros::Rotation horizontalEnc(nullptr);
// vertical tracking wheel encoder. Rotation sensor, port 11, reversed
// pros::Rotation verticalEnc(-11);
// horizontal tracking wheel. 2.75" diameter, 5.75" offset, back of the robot
// (negative)
// lemlib::TrackingWheel horizontal(&horizontalEnc, lemlib::Omniwheel::NEW_275,
// -5.75);
// vertical tracking wheel. 2.75" diameter, 2.5" offset, left of the robot
// (negative)
// lemlib::TrackingWheel vertical(&verticalEnc, lemlib::Omniwheel::NEW_275,
// -2.5);

// drivetrain settings
lemlib::Drivetrain drivetrain(
    &leftMotors,                // left motor group
    &rightMotors,               // right motor group
    11.375,                     // 10 inch track width
    lemlib::Omniwheel::NEW_325, // using new 3.25" omnis
    450,                        // drivetrain rpm is 450
    8 // horizontal drift is 2. If we had traction wheels, it would have been 8
);

// lateral motion controller
lemlib::ControllerSettings
    linearController(10.3, // proportional gain (kP)
                     0,    // integral gain (kI)
                     3,    // derivative gain (kD)
                     3,    // anti windup
                     1,    // small error range, in inches
                     100,  // small error range timeout, in milliseconds
                     3,    // large error range, in inches
                     500,  // large error range timeout, in milliseconds
                     70    // maximum acceleration (slew)
    );

// angular motion controller
lemlib::ControllerSettings
    angularController(1.71, // proportional gain (kP)
                      0,    // integral gain (kI)
                      11.8, // derivative gain (kD)
                      3,    // anti windup
                      1,    // small error range, in degrees
                      100,  // small error range timeout, in milliseconds
                      3,    // large error range, in degrees
                      500,  // large error range timeout, in milliseconds
                      0     // maximum acceleration (slew)
    );

// sensors for odometry
lemlib::OdomSensors sensors(nullptr, // vertical tracking wheel
                            nullptr, // vertical tracking wheel 2, set to
                                     // nullptr as we don't have a second one
                            nullptr, // horizontal tracking wheel
                            nullptr, // horizontal tracking wheel 2, set to
                                     // nullptr as we don't have a second one
                            &imu     // inertial sensor
);

// Test out increasing Curve, decreasing min output, and decreasing deadband

// input curve for throttle input during driver control. Decrease minoutput first
lemlib::ExpoDriveCurve
    throttleCurve(3,    // joystick deadband out of 127
                  10,   // minimum output where drivetrain will move out of 127
                  1.019 // expo curve gain
    );

// try decreasing curve, decreasing deadband, and decreasing min output --> should help dhruva turn more accurately at low speeds. Decrease curve first
lemlib::ExpoDriveCurve
    steerCurve(3,    // joystick deadband out of 127
               10,   // minimum output where drivetrain will move out of 127
               1.019 // expo curve gain
    );

// create the chassis
lemlib::Chassis chassis(drivetrain, linearController, angularController,
                        sensors, &throttleCurve, &steerCurve);

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */

double angles[] = {0, 44.20, 164.80, 80, 155}; 
int curAngle = 0;
double kP = 5;
double kD = 0.1; // Adjust this value as needed
double deadband = 0.1; // Prevents small unwanted movements
double prevError = 0;

void PIDcontrol() {
  while (true) {
    double target = angles[curAngle];
    double error = target - (rotationSensor.get_position() / 100.0);
    
    // Apply deadband to prevent small jittery movements
    if (fabs(error) > deadband) {
      double derivative = error - prevError;
      double vel = kP * error + kD * derivative;
      
      LadyBrown.move_velocity(vel);
      LadyBrown2.move_velocity(vel);
    } else {
      // Stop the motors if within deadband
      LadyBrown.move_velocity(0);
      LadyBrown2.move_velocity(0);
    }
    
    prevError = error;
    pros::delay(10);
  }
}


// Global variable to track the autonomous mode number
int autonomousMode = 1;

// Autonomous mode names
const char *autonNames[] = {
    "Skills",  
    "BlueAWP", 
    "RedAWP", 
    "BlueNegative", 
    "RedNegative", 
    "BluePositive", 
    "RedPositive", 
    "BlueGoalRush",
    "RedGoalRush"
};

void on_left_button() {
  if(autonomousMode == 1){
    autonomousMode=9;
  }
  else{
    autonomousMode--;
  }
}
void on_right_button() {
  if (autonomousMode == 9) {
      autonomousMode = 1;
  }
  else{
    autonomousMode++;
  }
}

bool colorSortOn = true;
bool noStop = true;

void colorSort() {
  while (true) {
    if(colorSortOn){
      colorSensor.set_led_pwm(100);
      int hue = colorSensor.get_hue();
    
      if (autonomousMode % 2 == 0) { // If autonomousMode is even, check for red
        if (hue < 50) {
          pros::delay(116);
          noStop = false;
          Intake.move_velocity(0); // Stop the motor
          pros::delay( 150); // Wait for 200 ms
          noStop = true;
          Intake.move_velocity(600); // Restart the motor (adjust speed as needed)
        }
      } else { // If autonomousMode is even, check for blue
        if (hue > 170 && hue < 230) {
          pros::delay(116);
          noStop = false;
          Intake.move_velocity(0); // Stop the motor
          pros::delay(150); // Wait for 200 ms
          noStop = true;
          Intake.move_velocity(600); // Restart the motor (adjust speed as needed)
        }
      }
    }
    
    pros::delay(10); // Small delay to prevent CPU overload
  }
}

// void displayInfo() {
//   while (true) {
//       master.clear();  // Clears previous text
//       master.print(0, 0, "Auton: %d", autonNames[autonomousMode - 1]); // Example auton selection
//       pros::delay(300); // Avoid spamming updates
//       if(master.get_digital(DIGITAL_LEFT)){
//         on_left_button();
//       }
//       if(master.get_digital(DIGITAL_RIGHT)){
//         on_right_button();
//       }
//   }
// }

void initialize() {
    pros::lcd::initialize(); // initialize brain screen
    chassis.calibrate();     // calibrate sensors
    imu.is_calibrating();
    rotationSensor.reset();
    rotationSensor.set_position(0);
    pros::Motor Intake(INTAKE_PORT);
    Intake.set_gearing(pros::E_MOTOR_GEAR_BLUE);
    Intake.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
    pros::Motor LadyBrown(LADYBROWN_PORT);
    LadyBrown.set_gearing(pros::E_MOTOR_GEAR_GREEN);
    LadyBrown.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
    pros::Motor LadyBrown2(LADYBROWN2_PORT);
    LadyBrown2.set_gearing(pros::E_MOTOR_GEAR_GREEN);
    LadyBrown2.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
    pros::adi::DigitalOut Clamp(CLAMP);
    pros::adi::DigitalOut Doinker(DOINKER);
    pros::Controller master(pros::E_CONTROLLER_MASTER);
    LadyBrown.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
    LadyBrown2.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
    pros::Task pidTask(PIDcontrol);
    pros::lcd::register_btn0_cb(on_left_button);  // Left button decreases mode
    // pros::lcd::register_btn1_cb(on_center_button); // Center button confirms selection
    pros::lcd::register_btn2_cb(on_right_button); // Right button increases mode
    //pros::Task colorCheckTask(colorSort);
    //pros::Task displayInfoTask(displayInfo);


  pros::Task screenTask([&]() {
    while (true) {
      // print robot location to the brain screen
      pros::lcd::print(0, "X: %f", chassis.getPose().x);         // x
      pros::lcd::print(1, "Y: %f", chassis.getPose().y);         // y
      pros::lcd::print(2, "Theta: %f", chassis.getPose().theta); // heading
      pros::lcd::print(3, autonNames[autonomousMode-1]);
      pros::lcd::print(4, colorSortOn ? "Color Sort On" : "Color Sort Off");
      // pros::lcd::print(5, "kp: %f", kP);
      // pros::lcd::print(6, "kD: %f", kD);
      // pros::lcd::print(7, "Green: %f", colorSensor.get_rgb().green);
      // pros::lcd::print(4, "Value: %f", autonomousMode);


      // log position telemetry
      lemlib::telemetrySink()->info("Chassis pose: {}", chassis.getPose());
      // delay to save resources
      pros::delay(50);
    }
  });
}

/**
 * Runs while the robot is disabled
 */
void disabled() {
  chassis.calibrate();
  imu.is_calibrating();
  rotationSensor.set_position(0);
  pros::Motor Intake(INTAKE_PORT);
  Intake.set_gearing(pros::E_MOTOR_GEAR_BLUE);
  Intake.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown(LADYBROWN_PORT);
  LadyBrown.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown2(LADYBROWN2_PORT);
  LadyBrown2.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown2.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::adi::DigitalOut Clamp(CLAMP);
  pros::adi::DigitalOut Doinker(DOINKER);
  pros::Controller master(pros::E_CONTROLLER_MASTER);
  LadyBrown.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  LadyBrown2.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  pros::Task pidTask(PIDcontrol);
  //pros::Task colorCheckTask(colorSort);
  //pros::Task displayInfoTask(displayInfo);
    
}

/**
 * runs after initialize if the robot is connected to field control
 */
void competition_initialize() {
  chassis.calibrate();
  imu.is_calibrating();
  rotationSensor.set_position(0);
  pros::Motor Intake(INTAKE_PORT);
  Intake.set_gearing(pros::E_MOTOR_GEAR_BLUE);
  Intake.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown(LADYBROWN_PORT);
  LadyBrown.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown2(LADYBROWN2_PORT);
  LadyBrown2.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown2.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::adi::DigitalOut Clamp(CLAMP);
  pros::adi::DigitalOut Doinker(DOINKER);
  pros::Controller master(pros::E_CONTROLLER_MASTER);
  LadyBrown.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  LadyBrown2.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  pros::Task pidTask(PIDcontrol);
 // pros::Task colorCheckTask(colorSort);
  //pros::Task displayInfoTask(displayInfo);

}

// get a path used for pure pursuit
// this needs to be put outside a function
// ASSET(example_txt); // '.' replaced with "_" to make c++ happy

/**
 * Runs during auto
 *
 * This is an example autonomous routine which demonstrates a lot of the
 * features LemLib has to offer
 */

void skills(){
  chassis.setPose(76.5,14.5,180);
  // alliiance stake
  curAngle = 4;
  pros::delay(1000);
  curAngle = 1;
  chassis.moveToPoint(76.5, 19, 2000, {.forwards = false});
  chassis.turnToHeading(230, 1000);
  // clamp first tower
  chassis.moveToPoint(93, 22, 2000, {.forwards=false, .maxSpeed=60});
  pros::delay(500);
  chassis.moveToPoint(95, 22, 2000, {.maxSpeed=40});
  Clamp.set_value(true);
  pros::delay(800);
  chassis.turnToHeading(0, 1000);
  Intake.move_velocity(600);
  // first ring
  chassis.moveToPoint(95, 48, 2000);
  pros::delay(2000);
  Intake.move_velocity(0);
  chassis.moveToPoint(122, 74, 5000, {.maxSpeed = 80});
  pros::delay(600);
  curAngle = 3;
  pros::delay(400);
  Intake.move_velocity(600);
  pros::delay(1000);
  chassis.turnToHeading(90, 1000);
  chassis.moveToPoint(128.6, 74, 2000, {.maxSpeed = 60});
  pros::delay(750);
  // score wall stake
  curAngle = 2;
  pros::delay(600);
  curAngle = 0;
  //2nd 3rd 4th 5th ring + drop
  chassis.moveToPoint(119, 74, 2000, {.forwards = false});
  pros::delay(500);
  chassis.turnToHeading(180, 1000);
  pros::delay(200);
  chassis.moveToPoint(121, 50, 2000);
  pros::delay(500);
  chassis.moveToPoint(121, 29.5, 2000, {.maxSpeed = 70});
  pros::delay(500);
  chassis.moveToPoint(121, 16, 2000, {.maxSpeed = 70});
  pros::delay(1000);
  chassis.turnToHeading(45, 1000);
  pros::delay(200);
  chassis.moveToPoint(130, 24, 2000, {.maxSpeed = 70});
  pros::delay(1200);
  chassis.turnToHeading(-35, 1000);
  chassis.moveToPoint(131, 17, 2000, {.forwards=false});
  pros::delay(600);
  Intake.move_velocity(-600);
  Clamp.set_value(false);

  // leave corner
  pros::delay(100);
  chassis.moveToPoint(120, 22.5, 5000, {.maxSpeed=80});
  chassis.turnToHeading(-90, 1000);
  pros::delay(300);
  Intake.move_velocity(-600);
  chassis.moveToPose(58, 22.5, 90, 5000,{.forwards = false, .maxSpeed = 80});
  Intake.move_velocity(0);
    //get second tower
  chassis.moveToPose(47.5, 22.5, 90, 5000,{.forwards = false});
  pros::delay(600);
  Clamp.set_value(true);
  pros::delay(800);
  chassis.turnToHeading(0, 1000);

  // 1st ring
  curAngle = 1;
  Intake.move_velocity(600);
  pros::delay(200);
  chassis.moveToPoint(43,46.5,2000);
  pros::delay(2000);
  chassis.turnToHeading(-45, 1000);
  Intake.move_velocity(0);
  chassis.moveToPoint(23, 69.5, 2000);
  chassis.turnToHeading(-90, 1000);
  curAngle = 3;
  pros::delay(200);
  Intake.move_velocity(600);
  chassis.moveToPoint(10,69.5,2000, {.maxSpeed = 60});
  pros::delay(1200);
  //score wall stake
  curAngle = 2;
  pros::delay(1000);
  curAngle = 0;
  chassis.moveToPoint(24, 69.5, 2000, {.forwards = false});
  //rest of  rings + score
  chassis.turnToHeading(180, 1000);
  chassis.moveToPoint(24, 50, 2000, {.maxSpeed = 70});
  pros::delay(500);
  chassis.moveToPoint(24, 32, 2000, {.maxSpeed = 70});
  pros::delay(500);
  chassis.moveToPoint(24, 15, 2000, {.maxSpeed = 70});
  pros::delay(1000);
  chassis.turnToHeading(-45, 1000);
  chassis.moveToPoint(15, 19, 2000);
  pros::delay(1000);
  chassis.moveToPoint(17, 17, 2000, {.forwards = false});
  chassis.turnToHeading(35, 1000);
  chassis.moveToPoint(12, 12, 2000, {.forwards = false});
  pros::delay(500);
  Intake.move_velocity(-600);
  pros::delay(500);
  Clamp.set_value(false);

  //pick up premature ring
  Intake.move_velocity(250);
  pros::delay(300);
  chassis.moveToPoint(27, 72, 3000, {.maxSpeed = 70});
  pros::delay(300);
  chassis.moveToPoint(46, 92, 2000, {.maxSpeed = 70});
  pros::delay(500);

  chassis.turnToHeading(180, 2000);
  Intake.move_velocity(0);
  //pick up third tower
  chassis.moveToPose(68, 114.5, 270,2000, {.forwards = false, .maxSpeed = 80});
  pros::delay(400);
  chassis.moveToPose(72,114.5,270, 1500, {.forwards = false});
  pros::delay(300);
  Clamp.set_value(true);
  pros::delay(200);
  Intake.move_velocity(600);
  pros::delay(300);
  //ring
  chassis.moveToPoint(22, 82, 4000);
  pros::delay(500);
  chassis.turnToHeading(190, 1000);
  //put in corner
  chassis.moveToPoint(9, 126, 2500, {.forwards = false, .maxSpeed = 80});
  Intake.move_velocity(-600);
  pros::delay(200);
  Intake.move_velocity(0);
  Clamp.set_value(false);
  chassis.moveToPoint(20, 100, 2000);
  chassis.turnToHeading(80, 3000);
  chassis.moveToPoint(72, 120, 2000);
  // final tower
  chassis.moveToPoint(130, 135, 2000, {.minSpeed = 60});
  pros::delay(500);
  chassis.moveToPoint(110, 130, 2000, {.minSpeed = 70});
  chassis.moveToPoint(70, 120, 3000, {.forwards = false});
}

void blueAWP(){
  kP=10;
  chassis.setPose(84, 20, 206);
  chassis.moveToPoint(82.5, 13.5, 2000);
  pros::delay(400);
  curAngle = 2;
  pros::delay(1000);
  chassis.moveToPoint(92.5, 34.5, 3000, {.forwards = false});
  curAngle = 0;
  kP=5;
  chassis.moveToPoint(98, 48, 3000, {.forwards = false, .maxSpeed=50});
  Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  chassis.turnToHeading(45, 1000);
  Intake.move_velocity(600);
  chassis.moveToPoint(115,64, 3000);
  pros::delay(100);
  chassis.moveToPoint(96, 51, 2000, {.forwards = false});
  chassis.turnToHeading(90, 600);
  chassis.moveToPoint(123, 51, 2000);
  pros::delay(50);
  chassis.moveToPoint(72,30, 2000, {.forwards = false});
  pros::delay(600);
  Clamp.set_value(false);
  chassis.turnToHeading(145, 700);
  chassis.moveToPoint(50, 55, 2000, {.forwards = false, .maxSpeed = 72});
  pros::delay(1000);
  Clamp.set_value(true);
  Intake.move_velocity(600);
  chassis.turnToHeading(-90, 700);
  chassis.moveToPoint(32, 54, 2000);
  pros::delay(100);
  chassis.turnToHeading(90, 1000);
  chassis.moveToPoint(95, 54, 1000, {.maxSpeed = 80});
}


void redAWP(){
  kP=10;
  chassis.setPose(84-1, 144-20, 334);
  chassis.moveToPoint(82.5-1, 144-13.5, 2000);
  pros::delay(400);
  curAngle = 2;
  pros::delay(1000);
  chassis.moveToPoint(92.5, 144-34.5, 3000, {.forwards = false});
  curAngle = 0;
  kP=5;
  chassis.moveToPoint(98, 144-48, 3000, {.forwards = false, .maxSpeed=50});
  Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  chassis.turnToHeading(135, 1000);
  Intake.move_velocity(600);
  chassis.moveToPoint(115,144-64+12, 3000);
  pros::delay(100);
  chassis.moveToPoint(96, 144-51+12, 2000, {.forwards = false});
  chassis.turnToHeading(90, 600);
  chassis.moveToPoint(123, 144-51+12, 2000);
  pros::delay(50);
  chassis.moveToPoint(72,144-30+12, 2000, {.forwards = false});
  pros::delay(600);
  Clamp.set_value(false);
  chassis.turnToHeading(55, 700);
  chassis.moveToPoint(48, 144-55+9, 2000, {.forwards = false, .maxSpeed = 72});
  pros::delay(1100);
  Clamp.set_value(true);
  Intake.move_velocity(600);
  chassis.turnToHeading(-90, 700);
  chassis.moveToPoint(27, 144-54+9, 2000);
  pros::delay(100);
  chassis.turnToHeading(90, 1000);
  chassis.moveToPoint(92, 144-54+9, 1000, {.minSpeed = 100});
}

void blueNegative(){
  // kP=10;
  // chassis.setPose(84, 20, 206);
  // // chassis.moveToPoint(82.5, 13, 2000);
  // // pros::delay(400);
  // // curAngle = 2;
  // // pros::delay(1000);
  // chassis.moveToPoint(91.5, 34.5, 3000, {.forwards = false});
  // // curAngle = 0;
  // // kP=5;
  // chassis.moveToPoint(98, 48, 3000, {.forwards = false, .maxSpeed=50});
  // // Intake.move_velocity(-600);
  // pros::delay(700);
  // Clamp.set_value(true);
  // pros::delay(500);
  // Intake.move_velocity(600);
  // pros::delay(100);
  // chassis.turnToHeading(45, 1000);
  // chassis.moveToPoint(115,64, 3000);
  // pros::delay(100);
  // chassis.moveToPoint(96, 53, 2000, {.forwards = false});
  // pros::delay(500);
  // chassis.turnToHeading(90, 600);
  // chassis.moveToPoint(123, 53, 2000);
  // pros::delay(400);
  // chassis.turnToHeading(-150, 1000);
  // chassis.moveToPose(92,24.5, -90, 2000);
  // pros::delay(1550);
  // Doinker.set_value(true);
  // pros::delay(200);
  // chassis.turnToHeading(-37, 1000);
  // pros::delay(400);
  // Doinker.set_value(false);
  // chassis.moveToPoint(81,39, 2000);  
  // pros::delay(1500);
  // chassis.moveToPoint(78, 53, 2000);
  kP=10;
  chassis.setPose(84, 20, 206);
  chassis.moveToPoint(82.5, 13, 2000);
  pros::delay(400);
  curAngle = 2;
  pros::delay(1000);
  chassis.moveToPoint(91.5, 34.5, 3000, {.forwards = false});
  curAngle = 0;
  kP=5;
  chassis.moveToPoint(98, 48, 3000, {.forwards = false, .maxSpeed=50});
  Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  chassis.turnToHeading(45, 1000);
  Intake.move_velocity(600);
  chassis.moveToPoint(119,62, 3000);
  pros::delay(100);
  chassis.turnToHeading(90, 600);
  chassis.moveToPoint(122, 63, 2000);
  pros::delay(100);
  chassis.moveToPoint(96, 51, 2000, {.forwards = false});
  pros::delay(500);
  chassis.turnToHeading(90, 600);
  chassis.moveToPoint(123, 53, 2000);
  pros::delay(400);
  chassis.turnToHeading(-150, 1000);
  chassis.moveToPose(94,24, -90, 2000);
  pros::delay(1600);
  Doinker.set_value(true);
  pros::delay(200);
  chassis.turnToHeading(-50, 1000);
  pros::delay(400);
  Doinker.set_value(false);
  chassis.moveToPoint(81,39, 2000);  
  chassis.turnToHeading(-90, 1000);
  // pros::delay(400);
  // chassis.moveToPoint(78, 51, 2000);
}

void redNegative(){
  kP=10;
  chassis.setPose(83, 144-20, 334);
  chassis.moveToPoint(81.5, 144-13, 2000);
  pros::delay(400);
  curAngle = 2;
  pros::delay(1000);
  chassis.moveToPoint(91.5, 144-34.5, 3000, {.forwards = false});
  curAngle = 0;
  kP=5;
  chassis.moveToPoint(98, 144-48, 3000, {.forwards = false, .maxSpeed=50});
  // Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  pros::delay(500);
  Intake.move_velocity(600);
  chassis.turnToHeading(135, 1000);
  // Intake.move_velocity(600);
  chassis.moveToPoint(115,144-66+12, 3000);
  pros::delay(300);
  chassis.turnToHeading(100, 600);
  chassis.moveToPoint(123, 144-70+14, 2000);
  pros::delay(200);
  chassis.moveToPoint(96, 144-53+12, 2000, {.forwards = false});
  pros::delay(500);
  chassis.turnToHeading(90, 600);
  chassis.moveToPoint(118, 144-53+12, 2000);
  // chassis.moveToPoint(118, 144-53+12, 2000);
  pros::delay(400);
  chassis.turnToHeading(-30, 1000);
  chassis.moveToPose(94-14+7,144-26, -90, 2000);
  pros::delay(1700);
  Doinker.set_value(true);
  chassis.moveToPoint(94-16+20, 144-30+9, 1000, {.forwards = false});
  // chassis.turnToHeading(90, 1000);
  // chassis.moveToPoint(75, 96, 2000);
  // pros::delay(800);
  pros::delay(200);
  chassis.turnToHeading(200, 1000);

  Doinker.set_value(false);
  // chassis.turnToHeading(160, 1000);
  pros::delay(400);
  // Doinker.set_value(false);
  // Intake.move_velocity(0);
  chassis.moveToPoint(81-18,144-30, 2000);  
  // pros::delay(400);
  // chassis.moveToPoint(78-14, 144-50, 2000);
}

void bluePositive(){
  kP=10;
  chassis.setPose(60, 20, 154);
  // chassis.moveToPoint(61.5, 13.5, 2000);
  // pros::delay(400);
  // curAngle = 2;
  // pros::delay(1000);
  chassis.moveToPoint(51.5, 34.5, 3000, {.forwards = false});
  // curAngle = 0;
  // kP=5;
  chassis.moveToPoint(46, 48, 3000, {.forwards = false, .maxSpeed=50});
  // Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  pros::delay(500);
  Intake.move_velocity(600);
  chassis.turnToHeading(-90, 1000);
  chassis.moveToPoint(28, 40, 3000);
  pros::delay(100);
  chassis.turnToHeading(90, 1000);
  chassis.moveToPoint(68, 48, 2000);
}

void redPositive(){
  kP=10;
  chassis.setPose(60, 144-20, 26);
  chassis.moveToPoint(62, 144-12.5, 2000);
  pros::delay(400);
  curAngle = 2;
  pros::delay(1000);
  chassis.moveToPoint(51.5, 144-34.5, 3000, {.forwards = false});
  curAngle = 0;
  kP=5;
  chassis.moveToPoint(46, 144-48, 3000, {.forwards = false, .maxSpeed=50});
  Intake.move_velocity(-600);
  pros::delay(700);
  Clamp.set_value(true);
  Intake.move_velocity(600);
  chassis.turnToHeading(-90, 1000);
  chassis.moveToPoint(28, 144-48, 3000);
  pros::delay(100);
  chassis.moveToPoint(66, 144-48, 2000);
}

void blueTournament(){
  // do later - prob sat night
  chassis.setPose(33, 22, 344);
  Intake.move_velocity(600);
  chassis.moveToPoint(27, 43, 2000, {.minSpeed = 60});
  pros::delay(800);
  Intake.move_velocity(0);
  //pros::delay(600);
  Doinker.set_value(true);
  pros::delay(100);
  chassis.moveToPoint(30, 38, 2000, {.forwards = false});
  pros::delay(500);
  Doinker.set_value(false);
  pros::delay(300);
  chassis.turnToHeading(245, 1000);
  chassis.moveToPoint(47, 48, 2000, {.forwards = false, .maxSpeed = 60});
  pros::delay(600);
  Intake.move_velocity(600);
  Clamp.set_value(true);
  pros::delay(400);
  chassis.turnToHeading(180, 1000);
  chassis.moveToPoint(44, 22, 2000);
  pros::delay(2000);
  chassis.turnToHeading(-45, 1000);
  pros::delay(500);
  Clamp.set_value(false);
  chassis.turnToHeading(145, 1000);


}


void redTournament(){
  // do later - prob sat night
  chassis.setPose(14, 124, 162);
  Intake.move_velocity(600);
  chassis.moveToPoint(25, 92, 2000);
  pros::delay(900);
  Intake.move_velocity(0);
  Doinker.set_value(true);
  pros::delay(700);
  chassis.moveToPoint(18, 99, 2000, {.forwards = false});
  pros::delay(400);
  Doinker.set_value(false);
  pros::delay(500);
  chassis.turnToHeading(-65, 1000);
  chassis.moveToPoint(48, 91, 2000, {.forwards = false, .maxSpeed = 60});
  pros::delay(1000);
  Clamp.set_value(true);
  Intake.move_velocity(600);
  chassis.moveToPoint(14, 116, 2000);
  pros::delay(400);
  chassis.turnToHeading(180, 1000);
  chassis.moveToPoint(14, 100, 2000);
  pros::delay(500);
  Clamp.set_value(false);
  pros::delay(500);
  chassis.turnToHeading(-20, 1000);
  

}


bool firstRun = true;

void autonomous() {
  if(firstRun){
    firstRun = false;
    switch(autonomousMode){
      case 1:
       skills(); 
      // blueTournament();
       break;
      case 2:
        blueAWP();
       break;
      case 3:
        redAWP();
       break;
      case 4:
        blueNegative();
       break;
      case 5:
        redNegative();
        break;
      case 6:
        bluePositive();
        break;
      case 7:
        redPositive();
        break;
      case 8:
        blueTournament();
        break;
      case 9:
        redTournament();
        break;
    }
  }
  
}

void opcontrol() {
  rotationSensor.set_position(0);
  pros::Motor Intake(INTAKE_PORT);
  Intake.set_gearing(pros::E_MOTOR_GEAR_BLUE);
  Intake.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown(LADYBROWN_PORT);
  LadyBrown.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::Motor LadyBrown2(LADYBROWN2_PORT);
  LadyBrown2.set_gearing(pros::E_MOTOR_GEAR_GREEN);
  LadyBrown2.set_encoder_units(pros::E_MOTOR_ENCODER_DEGREES);
  pros::adi::DigitalOut Clamp(CLAMP);
  pros::adi::DigitalOut Doinker(DOINKER);
  pros::Controller master(pros::E_CONTROLLER_MASTER);
  LadyBrown.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  LadyBrown2.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  pros::Task pidTask(PIDcontrol);
  // pros::Task colorCheckTask(colorSort);

  // controller
  // loop to continuously update motors
  while (true) {
    // get joystick positions
    int leftY = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int rightY = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
    // move the chassis with curvature drive
    chassis.tank(leftY, rightY);

    // intake
    if (master.get_digital(DIGITAL_R2) && noStop) {
      Intake.move_velocity(600);
    } else if (master.get_digital(DIGITAL_L2)) {
      Intake.move_velocity(-600);
    } else {
      Intake.move_velocity(0);
    }

    // clamp
    static bool toggle = false;
    if (master.get_digital_new_press(DIGITAL_B)) {
      if (!toggle) {
        Clamp.set_value(true);
        toggle = !toggle;
      } else {
        Clamp.set_value(false);
        toggle = !toggle;
      }
    }

    // doinker
    static bool toggle2 = false;
    if (master.get_digital_new_press(DIGITAL_DOWN)) {
      if (!toggle2) {
        Doinker.set_value(true);
        toggle2 = !toggle2;
      } else {
        Doinker.set_value(false);
        toggle2 = !toggle2;
      }
    }

    // lady brown
    if(master.get_digital_new_press(DIGITAL_R1)){
      curAngle++;
      curAngle = curAngle % 3;
    }

    // color sort
    if(master.get_digital_new_press(DIGITAL_UP)){
      colorSortOn = !colorSortOn;
    }
    // delay to save resources
    pros::delay(10);
  }
}